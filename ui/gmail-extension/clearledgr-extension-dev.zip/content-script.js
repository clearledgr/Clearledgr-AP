/**
 * Clearledgr Content Script
 *
 * Intentionally left minimal for AP v1.
 * InboxSDK layer owns initialization and UI.
 */
