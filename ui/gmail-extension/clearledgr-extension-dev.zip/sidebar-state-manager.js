class SidebarStateManager {
  constructor() {
    this.currentEmail = null;
    this.currentMatch = null;
    this.listeners = [];
  }

  setEmail(emailData) {
    this.currentEmail = emailData;
    this.notifyListeners('EMAIL_UPDATED', emailData);
  }

  setMatch(matchData) {
    this.currentMatch = matchData;
    this.notifyListeners('MATCH_UPDATED', matchData);
  }

  subscribe(callback) {
    this.listeners.push(callback);
    return () => this.listeners = this.listeners.filter(l => l !== callback);
  }

  notifyListeners(type, data) {
    this.listeners.forEach(listener => listener({ type, data }));
  }
}

if (typeof window !== 'undefined') {
  window.SidebarStateManager = SidebarStateManager;
}